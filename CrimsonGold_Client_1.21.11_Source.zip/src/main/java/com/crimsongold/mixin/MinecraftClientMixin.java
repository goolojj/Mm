package com.crimsongold.mixin;

import com.crimsongold.CrimsonGoldClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "hasOutline", at = @At("HEAD"), cancellable = true)
    private void onHasOutline(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (CrimsonGoldClient.CONFIG != null && CrimsonGoldClient.CONFIG.outlineEnabled && entity != null) {
            MinecraftClient self = (MinecraftClient) (Object) this;
            if (self.player != null && entity != self.player && entity.isAlive() && entity.distanceTo(self.player) < 32.0f) {
                cir.setReturnValue(true);
            }
        }
    }
}
