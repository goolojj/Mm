package com.crimsongold.gui;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

public class CrimsonClickGui extends Screen {
    private enum Category { ALL, PVP, FPS, HUD }

    private record ModuleCard(String name, String desc, Category cat, BooleanSupplier getter, Runnable toggler, int x, int y, int w, int h) {}

    private Category activeCategory = Category.ALL;
    private int page = 0;
    private int totalPages = 1;
    private final List<ModuleCard> visibleCards = new ArrayList<>();
    private final List<int[]> tabBounds = new ArrayList<>();

    private int winX, winY, winW, winH;
    private int closeX, closeY, closeW, closeH;
    private int blurBtnX, blurBtnY, blurBtnW, blurBtnH;
    private int prevX, prevY, nextX, nextY, navW = 46, navH = 16;

    public CrimsonClickGui() {
        super(Text.literal("CrimsonGold Client"));
    }

    @Override
    protected void init() {
        visibleCards.clear();
        tabBounds.clear();

        // Compact centered window that avoids mobile touch controls
        winW = Math.min(390, this.width - 40);
        winH = Math.min(220, this.height - 30);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        int sideW = 82;

        // Sidebar Category Tabs
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int tx = winX + 8;
            int ty = winY + 34 + i * 24;
            int tw = sideW - 16;
            int th = 20;
            tabBounds.add(new int[]{tx, ty, tw, th});
            Category c = cats[i];
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                activeCategory = c;
                page = 0;
                this.clearAndInit();
            }).dimensions(tx, ty, tw, th).build());
        }

        // Motion Blur Strength Button
        blurBtnX = winX + 8;
        blurBtnY = winY + winH - 50;
        blurBtnW = sideW - 16;
        blurBtnH = 18;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            cfg.motionBlurLevel = (cfg.motionBlurLevel % 3) + 1;
            cfg.save();
        }).dimensions(blurBtnX, blurBtnY, blurBtnW, blurBtnH).build());

        // Close Button
        closeX = winX + 8;
        closeY = winY + winH - 26;
        closeW = sideW - 16;
        closeH = 18;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            cfg.save();
            this.close();
        }).dimensions(closeX, closeY, closeW, closeH).build());

        // 16+ Modules across PVP, FPS, HUD
        List<ModuleCard> all = new ArrayList<>();
        all.add(new ModuleCard("Mini Target HUD", "Compact Enemy HP", Category.PVP, () -> cfg.hitboxEnabled, () -> { cfg.hitboxEnabled = !cfg.hitboxEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Reach Display", "Show Last Hit Dist", Category.PVP, () -> cfg.reachDisplayEnabled, () -> { cfg.reachDisplayEnabled = !cfg.reachDisplayEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Entity Outline", "Glow Targets <32m", Category.PVP, () -> cfg.outlineEnabled, () -> { cfg.outlineEnabled = !cfg.outlineEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("ToggleSprint", "Auto Sprint", Category.PVP, () -> cfg.toggleSprintEnabled, () -> { cfg.toggleSprintEnabled = !cfg.toggleSprintEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("ToggleSneak", "Auto Crouch Hold", Category.PVP, () -> cfg.toggleSneakEnabled, () -> { cfg.toggleSneakEnabled = !cfg.toggleSneakEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("NoHurtCam", "No Damage Shake", Category.PVP, () -> cfg.noHurtCamEnabled, () -> { cfg.noHurtCamEnabled = !cfg.noHurtCamEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Target Dot", "Crosshair Glow", Category.PVP, () -> cfg.crosshairDotEnabled, () -> { cfg.crosshairDotEnabled = !cfg.crosshairDotEnabled; cfg.save(); }, 0, 0, 0, 0));

        all.add(new ModuleCard("FPS Boost All", "Max Mobile FPS", Category.FPS, () -> cfg.fpsBoostEnabled, () -> { cfg.fpsBoostEnabled = !cfg.fpsBoostEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("No Shadows", "Hide Entity Shadow", Category.FPS, () -> cfg.noShadowsEnabled, () -> { cfg.noShadowsEnabled = !cfg.noShadowsEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("No Bobbing", "Steady Camera", Category.FPS, () -> cfg.noBobbingEnabled, () -> { cfg.noBobbingEnabled = !cfg.noBobbingEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Fast Chunks", "0 Biome Blend", Category.FPS, () -> cfg.zeroBiomeBlendEnabled, () -> { cfg.zeroBiomeBlendEnabled = !cfg.zeroBiomeBlendEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Motion Blur", "Smooth Turn Blur", Category.FPS, () -> cfg.motionBlurEnabled, () -> { cfg.motionBlurEnabled = !cfg.motionBlurEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Fullbright", "Max Cave Light", Category.FPS, () -> cfg.fullbrightEnabled, () -> { cfg.fullbrightEnabled = !cfg.fullbrightEnabled; cfg.save(); }, 0, 0, 0, 0));

        all.add(new ModuleCard("Keystrokes", "WASD + Space + CPS", Category.HUD, () -> cfg.keystrokesEnabled, () -> { cfg.keystrokesEnabled = !cfg.keystrokesEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Armor HUD", "Equipped Gear", Category.HUD, () -> cfg.armorHudEnabled, () -> { cfg.armorHudEnabled = !cfg.armorHudEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("FPS & Info", "FPS / XYZ / CPS", Category.HUD, () -> cfg.cpsCounterEnabled, () -> { cfg.cpsCounterEnabled = !cfg.cpsCounterEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Sprint Pill", "Bottom Badge", Category.HUD, () -> cfg.sprintPillEnabled, () -> { cfg.sprintPillEnabled = !cfg.sprintPillEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Master HUD", "All Overlays", Category.HUD, () -> cfg.hudEnabled, () -> { cfg.hudEnabled = !cfg.hudEnabled; cfg.save(); }, 0, 0, 0, 0));

        List<ModuleCard> filtered = new ArrayList<>();
        for (ModuleCard m : all) {
            if (activeCategory == Category.ALL || m.cat() == activeCategory) filtered.add(m);
        }

        int perPage = 8; // 2 cols x 4 rows cleanly
        totalPages = Math.max(1, (int) Math.ceil(filtered.size() / (double) perPage));
        if (page >= totalPages) page = totalPages - 1;

        int gridX = winX + sideW + 8;
        int gridY = winY + 34;
        int availW = winW - sideW - 16;
        int cardW = (availW - 6) / 2;
        int cardH = 34;

        int start = page * perPage;
        int end = Math.min(filtered.size(), start + perPage);
        for (int i = start; i < end; i++) {
            int local = i - start;
            int col = local % 2;
            int row = local / 2;
            int cx = gridX + col * (cardW + 6);
            int cy = gridY + row * (cardH + 5);
            ModuleCard m = filtered.get(i);
            ModuleCard placed = new ModuleCard(m.name(), m.desc(), m.cat(), m.getter(), m.toggler(), cx, cy, cardW, cardH);
            visibleCards.add(placed);
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> placed.toggler().run())
                    .dimensions(cx, cy, cardW, cardH).build());
        }

        // Page Prev / Next Buttons
        prevX = gridX;
        prevY = winY + winH - 24;
        nextX = winX + winW - navW - 8;
        nextY = prevY;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            if (page > 0) { page--; this.clearAndInit(); }
        }).dimensions(prevX, prevY, navW, navH).build());
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            if (page < totalPages - 1) { page++; this.clearAndInit(); }
        }).dimensions(nextX, nextY, navW, navH).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x8805040A);

        // Main Frosted Dark-Glass Window
        ctx.fill(winX, winY, winX + winW, winY + winH, 0xEE0D0C14);
        drawBorder(ctx, winX, winY, winW, winH, 0xFFFFD466);
        drawBorder(ctx, winX + 1, winY + 1, winW - 2, winH - 2, 0xFFC41E44);

        // Header Bar
        ctx.fill(winX + 2, winY + 2, winX + winW - 2, winY + 26, 0xFF180D16);
        ctx.fill(winX + 2, winY + 26, winX + winW - 2, winY + 27, 0xFFC41E44);
        ctx.drawTextWithShadow(this.textRenderer, "§6§lCRIMSON§c§lGOLD §fCLIENT", winX + 10, winY + 10, 0xFFFFFFFF);
        String ver = "§71.21.11  •  §6v1.0.3";
        ctx.drawTextWithShadow(this.textRenderer, ver, winX + winW - this.textRenderer.getWidth(ver) - 10, winY + 10, 0xFFFFFFFF);

        // Sidebar Divider
        int sideW = 82;
        ctx.fill(winX + sideW, winY + 27, winX + sideW + 1, winY + winH - 2, 0x77C41E44);

        // Render Sidebar Tabs (NOTE: 0xFF alpha on all colors!)
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] b = tabBounds.get(i);
            boolean active = (cats[i] == activeCategory);
            boolean hov = isHover(mouseX, mouseY, b[0], b[1], b[2], b[3]);
            int bg = active ? 0xDD3D1224 : (hov ? 0xAA24161F : 0x7714121B);
            int brd = active ? 0xFFFFD466 : (hov ? 0xFFC41E44 : 0x44FFFFFF);
            ctx.fill(b[0], b[1], b[0] + b[2], b[1] + b[3], bg);
            drawBorder(ctx, b[0], b[1], b[2], b[3], brd);
            if (active) ctx.fill(b[0], b[1] + 2, b[0] + 2, b[1] + b[3] - 2, 0xFFFFD466);
            String label = cats[i].name();
            int tw = this.textRenderer.getWidth(label);
            ctx.drawTextWithShadow(this.textRenderer, label, b[0] + (b[2] - tw) / 2, b[1] + 6, active ? 0xFFFFD466 : 0xFFDDDDDD);
        }

        // Blur Level Button
        String blurLvl = switch (CrimsonGoldClient.CONFIG.motionBlurLevel) {
            case 1 -> "Blur: LOW";
            case 3 -> "Blur: HIGH";
            default -> "Blur: MED";
        };
        boolean blurHov = isHover(mouseX, mouseY, blurBtnX, blurBtnY, blurBtnW, blurBtnH);
        ctx.fill(blurBtnX, blurBtnY, blurBtnX + blurBtnW, blurBtnY + blurBtnH, blurHov ? 0xCC2A1520 : 0xAA16131E);
        drawBorder(ctx, blurBtnX, blurBtnY, blurBtnW, blurBtnH, 0xAAFFD466);
        ctx.drawCenteredTextWithShadow(this.textRenderer, blurLvl, blurBtnX + blurBtnW / 2, blurBtnY + 5, 0xFFFFD466);

        // Close Button
        boolean closeHov = isHover(mouseX, mouseY, closeX, closeY, closeW, closeH);
        ctx.fill(closeX, closeY, closeX + closeW, closeY + closeH, closeHov ? 0xDDC41E44 : 0xAA68142A);
        drawBorder(ctx, closeX, closeY, closeW, closeH, 0xFFFFD466);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Close", closeX + closeW / 2, closeY + 5, 0xFFFFFFFF);

        // Module Cards
        for (ModuleCard c : visibleCards) {
            boolean on = c.getter().getAsBoolean();
            boolean hov = isHover(mouseX, mouseY, c.x(), c.y(), c.w(), c.h());
            int cardBg = on ? (hov ? 0xDD28131E : 0xCC1B0F17) : (hov ? 0xBB1B1924 : 0xAA12111A);
            int cardBrd = hov ? 0xFFFFD466 : (on ? 0xFFC41E44 : 0x44FFFFFF);
            ctx.fill(c.x(), c.y(), c.x() + c.w(), c.y() + c.h(), cardBg);
            drawBorder(ctx, c.x(), c.y(), c.w(), c.h(), cardBrd);
            if (on) ctx.fill(c.x(), c.y() + 4, c.x() + 2, c.y() + c.h() - 4, 0xFFFFD466);

            ctx.drawTextWithShadow(this.textRenderer, c.name(), c.x() + 7, c.y() + 6, on ? 0xFFFFFFFF : 0xFFBBBBCC);
            ctx.drawText(this.textRenderer, c.desc(), c.x() + 7, c.y() + 19, 0xFF8C8296, false);

            // Toggle Pill
            int sw = 22, sh = 10;
            int sx = c.x() + c.w() - sw - 6;
            int sy = c.y() + (c.h() - sh) / 2;
            ctx.fill(sx, sy, sx + sw, sy + sh, on ? 0xFF28A745 : 0xFF2C2836);
            drawBorder(ctx, sx, sy, sw, sh, on ? 0xFFFFD466 : 0x66FFFFFF);
            int knobX = on ? (sx + sw - 8) : (sx + 2);
            ctx.fill(knobX, sy + 2, knobX + 6, sy + sh - 2, on ? 0xFFFFD466 : 0xFF9999AA);
        }

        // Page Controls
        ctx.fill(prevX, prevY, prevX + navW, prevY + navH, page > 0 ? 0xAA24141E : 0x55121018);
        drawBorder(ctx, prevX, prevY, navW, navH, page > 0 ? 0xFFFFD466 : 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "< Prev", prevX + navW / 2, prevY + 4, page > 0 ? 0xFFFFFFFF : 0xFF666677);

        String pgTxt = "Page " + (page + 1) + " / " + totalPages;
        ctx.drawCenteredTextWithShadow(this.textRenderer, pgTxt, (prevX + navW + nextX) / 2, prevY + 4, 0xFFCCCCCC);

        ctx.fill(nextX, nextY, nextX + navW, nextY + navH, page < totalPages - 1 ? 0xAA24141E : 0x55121018);
        drawBorder(ctx, nextX, nextY, navW, nextY + navH > 0 ? navH : 16, page < totalPages - 1 ? 0xFFFFD466 : 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Next >", nextX + navW / 2, nextY + 4, page < totalPages - 1 ? 0xFFFFFFFF : 0xFF666677);
    }

    private boolean isHover(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
