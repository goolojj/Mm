package com.crimsongold;

import com.crimsongold.config.ClientConfig;
import com.crimsongold.gui.CrimsonClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class CrimsonGoldClient implements ClientModInitializer {
    public static ClientConfig CONFIG;
    public static KeyBinding MENU_KEY;
    public static KeyBinding ZOOM_KEY;

    private static boolean wasZooming = false;
    private static int savedFov = 70;

    private static final Deque<Long> LEFT_CLICKS = new ArrayDeque<>();
    private static final Deque<Long> RIGHT_CLICKS = new ArrayDeque<>();
    private static boolean prevLeftDown = false;
    private static boolean prevRightDown = false;

    public static float lastReachBlocks = 0.0f;
    public static long lastHitTimeMs = 0L;

    @Override
    public void onInitializeClient() {
        CONFIG = ClientConfig.load();

        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crimsongold.menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crimsongold.zoom",
                GLFW.GLFW_KEY_C,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (MENU_KEY.wasPressed()) {
                client.setScreen(new CrimsonClickGui());
            }

            // Smooth Zoom
            boolean zooming = ZOOM_KEY.isPressed();
            if (zooming && !wasZooming) {
                savedFov = client.options.getFov().getValue();
                client.options.getFov().setValue(Math.max(30, savedFov / 3));
            } else if (!zooming && wasZooming) {
                client.options.getFov().setValue(savedFov);
            }
            wasZooming = zooming;

            // ToggleSprint & ToggleSneak
            if (CONFIG.toggleSprintEnabled && client.options.forwardKey.isPressed() && !client.player.isSneaking()) {
                client.player.setSprinting(true);
            }
            if (CONFIG.toggleSneakEnabled) {
                client.options.sneakKey.setPressed(true);
            }

            // FPS Boosters
            if (CONFIG.fpsBoostEnabled || CONFIG.noShadowsEnabled) {
                client.options.getEntityShadows().setValue(false);
            }
            if (CONFIG.fpsBoostEnabled || CONFIG.noBobbingEnabled) {
                client.options.getBobView().setValue(false);
            }
            if (CONFIG.fpsBoostEnabled || CONFIG.zeroBiomeBlendEnabled) {
                client.options.getBiomeBlendRadius().setValue(0);
            }

            // Fullbright
            if (CONFIG.fullbrightEnabled) {
                client.options.getGamma().setValue(1.0);
            }

            // Track CPS & Reach Display
            long now = System.currentTimeMillis();
            boolean leftDown = client.options.attackKey.isPressed();
            boolean rightDown = client.options.useKey.isPressed();
            if (leftDown && !prevLeftDown) {
                LEFT_CLICKS.addLast(now);
                if (client.crosshairTarget instanceof EntityHitResult ehr) {
                    lastReachBlocks = client.player.distanceTo(ehr.getEntity());
                    lastHitTimeMs = now;
                }
            }
            if (rightDown && !prevRightDown) RIGHT_CLICKS.addLast(now);
            prevLeftDown = leftDown;
            prevRightDown = rightDown;

            while (!LEFT_CLICKS.isEmpty() && now - LEFT_CLICKS.peekFirst() > 1000L) LEFT_CLICKS.removeFirst();
            while (!RIGHT_CLICKS.isEmpty() && now - RIGHT_CLICKS.peekFirst() > 1000L) RIGHT_CLICKS.removeFirst();
        });
    }

    public static int getLeftCps() {
        return LEFT_CLICKS.size();
    }

    public static int getRightCps() {
        return RIGHT_CLICKS.size();
    }
}
