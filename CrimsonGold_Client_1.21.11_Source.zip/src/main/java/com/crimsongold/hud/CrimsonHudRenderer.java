package com.crimsongold.hud;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;

public class CrimsonHudRenderer {
    private static float prevYaw = 0f;
    private static float prevPitch = 0f;
    private static float smoothBlur = 0f;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        if (cfg == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Smooth Motion Blur
        if (cfg.motionBlurEnabled) {
            float yawDelta = Math.abs(mc.player.getYaw() - prevYaw);
            if (yawDelta > 180f) yawDelta = 360f - yawDelta;
            float pitchDelta = Math.abs(mc.player.getPitch() - prevPitch);
            float rawSpeed = Math.min(1.0f, (yawDelta + pitchDelta) / 14.0f);
            smoothBlur = smoothBlur * 0.78f + rawSpeed * 0.45f;
            if (smoothBlur > 0.02f) {
                float mult = cfg.motionBlurLevel == 1 ? 0.55f : (cfg.motionBlurLevel == 3 ? 1.45f : 1.0f);
                int alpha = Math.min(130, (int) (smoothBlur * mult * 90));
                ctx.fill(0, 0, sw, sh, ((alpha / 2) << 24) | 0x160912);
                int edgeW = Math.max(16, sw / 8);
                ctx.fill(0, 0, edgeW, sh, (alpha << 24) | 0x1A0A14);
                ctx.fill(sw - edgeW, 0, sw, sh, (alpha << 24) | 0x1A0A14);
            }
            prevYaw = mc.player.getYaw();
            prevPitch = mc.player.getPitch();
        }

        if (!cfg.hudEnabled) return;

        // Top-Left Compact Pill: FPS + XYZ + CPS + Reach
        if (cfg.cpsCounterEnabled) {
            String reachStr = (cfg.reachDisplayEnabled && System.currentTimeMillis() - CrimsonGoldClient.lastHitTimeMs < 3000L)
                    ? String.format("  §8|  §e%.2fm", CrimsonGoldClient.lastReachBlocks)
                    : "";
            String line = "§6FPS §f" + mc.getCurrentFps()
                    + String.format("  §8|  §6XYZ §f%d %d %d", (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ())
                    + "  §8|  §cCPS §f" + CrimsonGoldClient.getLeftCps() + "|" + CrimsonGoldClient.getRightCps()
                    + reachStr;

            int boxW = mc.textRenderer.getWidth(line) + 10;
            ctx.fill(6, 6, 6 + boxW, 20, 0xBB0B0A10);
            drawBoxBorder(ctx, 6, 6, boxW, 14, 0xFFC41E44);
            ctx.drawTextWithShadow(mc.textRenderer, line, 11, 9, 0xFFFFFFFF);
        }

        // Crosshair Target Dot (glows Crimson/Gold when aiming at an entity)
        boolean aimingAtEntity = mc.crosshairTarget instanceof EntityHitResult;
        if (cfg.crosshairDotEnabled && aimingAtEntity) {
            int cx = sw / 2;
            int cy = sh / 2;
            ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFD466);
            ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFC41E44);
        }

        // Super Compact Mini Target Pill (never blocks screen!)
        if (cfg.hitboxEnabled && aimingAtEntity && mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity target = ehr.getEntity();
            String hp = (target instanceof LivingEntity le)
                    ? String.format(" §c%.0f♥", le.getHealth())
                    : "";
            String txt = "§6" + target.getName().getString() + hp + String.format(" §7%.1fm", mc.player.distanceTo(target));
            int tw = mc.textRenderer.getWidth(txt) + 10;
            int tx = (sw - tw) / 2;
            int ty = 6;
            ctx.fill(tx, ty, tx + tw, ty + 14, 0xBB0C0A12);
            drawBoxBorder(ctx, tx, ty, tw, 14, 0xFFFFD466);
            ctx.drawTextWithShadow(mc.textRenderer, txt, tx + 5, ty + 3, 0xFFFFFFFF);
        }

        // Keystrokes
        if (cfg.keystrokesEnabled) {
            int kx = 6;
            int ky = 25;
            drawKey(ctx, mc, kx + 20, ky, 18, 16, "W", mc.options.forwardKey.isPressed());
            drawKey(ctx, mc, kx, ky + 18, 18, 16, "A", mc.options.leftKey.isPressed());
            drawKey(ctx, mc, kx + 20, ky + 18, 18, 16, "S", mc.options.backKey.isPressed());
            drawKey(ctx, mc, kx + 40, ky + 18, 18, 16, "D", mc.options.rightKey.isPressed());
            drawKey(ctx, mc, kx, ky + 36, 28, 14, "LMB", mc.options.attackKey.isPressed());
            drawKey(ctx, mc, kx + 30, ky + 36, 28, 14, "RMB", mc.options.useKey.isPressed());
            drawKey(ctx, mc, kx, ky + 52, 58, 10, "---", mc.options.jumpKey.isPressed());
        }

        // Bottom-Left Sprint Pill
        if (cfg.sprintPillEnabled && cfg.toggleSprintEnabled) {
            String sp = mc.player.isSprinting() ? "§a[Sprinting]" : "§7[Sprint Ready]";
            int pw = mc.textRenderer.getWidth(sp) + 8;
            ctx.fill(6, sh - 18, 6 + pw, sh - 6, 0xAA0B0A10);
            drawBoxBorder(ctx, 6, sh - 18, pw, 12, 0x88FFD466);
            ctx.drawTextWithShadow(mc.textRenderer, sp, 10, sh - 16, 0xFFFFFFFF);
        }

        // Armor HUD
        if (cfg.armorHudEnabled) {
            int ax = sw - 22;
            int ay = sh - 22;
            EquipmentSlot[] slots = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
            for (EquipmentSlot slot : slots) {
                ItemStack stack = mc.player.getEquippedStack(slot);
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, ax, ay);
                    ctx.drawStackOverlay(mc.textRenderer, stack, ax, ay);
                }
                ay -= 18;
            }
        }
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xCCFFD466 : 0xB00B0A10;
        int border = pressed ? 0xFFFFFFFF : 0xFFC41E44;
        int txtCol = pressed ? 0xFF100810 : 0xFFFFFFFF;
        ctx.fill(x, y, x + w, y + h, bg);
        drawBoxBorder(ctx, x, y, w, h, border);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, txtCol, false);
    }

    private static void drawBoxBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }
}
